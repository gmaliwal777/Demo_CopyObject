//
//  ViewController.h
//  CopyDemo
//
//  Created by Ghanshyam on 2/16/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Model.h"

@interface ViewController : UIViewController{
    Model   *modelA;
    NSArray *arrModels;
    NSArray  *arrModeling;
}

@property (nonatomic,retain)   IBOutlet   UILabel *lbl;

@end

