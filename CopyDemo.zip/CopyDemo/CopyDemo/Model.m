//
//  Model.m
//  CopyDemo
//
//  Created by Ghanshyam on 2/16/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "Model.h"

@implementation Model


-(id)copyWithZone:(NSZone *)zone{
    Model *model = [[self class] allocWithZone:zone];
    model->name = self->name;
    model->address = self->address;
    model->idVal = self->idVal;
    return model;
}


#pragma mark--
#pragma mark-- Setter & Getters
-(void)setName:(NSString *)_name{
    self->name = _name;
}

-(NSString *)getName{
    return name;
}

-(void)setAddress:(NSString *)_address{
    self->address = _address;
}
-(NSString *)getAddress{
    return address;
}


-(void)setIDVal:(NSNumber *)_idVal{
    self->idVal = _idVal;
}

-(NSNumber *)getIDVal{
    return idVal;
}



@end
