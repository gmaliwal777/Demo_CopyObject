//
//  Model.h
//  CopyDemo
//
//  Created by Ghanshyam on 2/16/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject<NSCopying>{
    NSString    *name;
    NSString    *address;
    NSNumber    *idVal;
}


-(NSString *)getAddress;
-(void)setAddress:(NSString *)_address;
-(NSString *)getName;
-(void)setName:(NSString *)_name;
-(NSNumber *)getIDVal;
-(void)setIDVal:(NSNumber *)_idVal;


@end
