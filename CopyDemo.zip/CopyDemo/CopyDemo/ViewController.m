//
//  ViewController.m
//  CopyDemo
//
//  Created by Ghanshyam on 2/16/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

#pragma mark--
#pragma mark-- ViewController Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    NSLog(@"here");
    dispatch_async(dispatch_get_main_queue(), ^{
         NSLog(@"Hi There");
    });
    
    
    Model*  model = [[Model alloc] init];
    //modelA set
    [model setName:@"Ghanshyam"];
    [model setAddress:@"Jaipur, India"];
    [model setIDVal:[NSNumber numberWithInt:2003]];
    arrModels = [[NSArray alloc] initWithObjects:model, nil];
    arrModeling = [arrModels retain];
    
    
    //Getting Models where names start with Ghan
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.name like[c] %@",@"Ghan*"];
    NSLog(@"count for name like Ghan is %ld",[[arrModels filteredArrayUsingPredicate:predicate] count]);
    
    
    //Getting Models where name consist sh
    predicate = [NSPredicate predicateWithFormat:@"SELF.name like[cd] %@",@"*sh*"];
     NSLog(@"count for name consist sh is %ld",[[arrModels filteredArrayUsingPredicate:predicate] count]);
    
    //Getting Model where idVal is equal to 2003
    predicate = [NSPredicate predicateWithFormat:@"SELF.idVal == %d",2003];
    NSLog(@"ids where less than 2004 count is %ld",[[arrModels filteredArrayUsingPredicate:predicate] count]);
    
    
    //Getting Model where Address is not null
    predicate = [NSPredicate predicateWithFormat:@"SELF.address != NULL"];
    NSLog(@"where address is not null count is %ld",[[arrModels filteredArrayUsingPredicate:predicate] count]);
    
    
    
    Model *copyModel = [model copy];
    [copyModel setName:@"Rakesh"];
    
    NSLog(@"model name is %@",[model getName]);
    
    NSLog(@"copymodel name is %@",[copyModel getName]);
    
    
}

-(void)dateUTC{
    
    NSDate *currentDate = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [formatter setLocale:locale];
    [formatter setDateFormat:@"mm/dd/yyyy"];
    
    NSLog(@"date is %@",[formatter stringFromDate:currentDate]);
    
}


-(IBAction)generateCopy{
    
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//       NSString *someStr = @"Ghanu";
//        self.lbl.text = someStr;
//    });
    
    /*dispatch_async(dispatch_get_main_queue(), ^{
        NSString *someStr = @"Ghanu";
        self.lbl.text = someStr;
    });
    
    
    
    NSArray *arrCopy = [[NSArray alloc] initWithArray:arrModels copyItems:YES];
    
    NSLog(@"Arrary name is %@",[((Model *)[arrModels objectAtIndex:0]) getName]);
    NSLog(@"copy array name is %@",[((Model *)[arrCopy objectAtIndex:0]) getName]);
    [((Model *)[arrCopy objectAtIndex:0]) setName:@"Rajesh"];
     NSLog(@"copy array name is %@",[((Model *)[arrCopy objectAtIndex:0]) getName]);*/
    
    
    [self arrayCopy];
    
}

-(void)arrayCopy{
    
    [arrModels release];
    [arrModels release];
    
    
}

-(IBAction)displyaValue{
    NSLog(@"data is %@",arrModeling);
}

@end
